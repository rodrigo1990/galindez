
<h1>FORMULARIO GALINDEZ WEB</h1>

<b>Nombre:</b> {{$consulta->nombre}}<br>
<b>Fecha:</b> {{$consulta->fecha}}<br>
<b>Email:</b> {{$consulta->email}}<br>

<b>Lugar:</b> {{$consulta->lugar}}<br>

<b>Telefono:</b> {{$consulta->telefono}}<br>
<b>Cantidad:</b> {{$consulta->cantidad}}<br>
<b>Perfil de evento:</b> {{$consulta->perfil_evento}}<br>
<b>Tipo de evento:</b> {{$consulta->tipo_evento}}<br>
<b>Tipo de servicio:</b> {{$consulta->tipo_servicio}}<br>

<b>Menu:</b> {{$consulta->menu}}<br>

<b>Consulta:</b> {{$consulta->consulta}}<br>

