
<h1>FORMULARIO GALINDEZ WEB</h1>

<b>Nombre:</b> <?php echo e($consulta->nombre); ?><br>
<b>Fecha:</b> <?php echo e($consulta->fecha); ?><br>
<b>Email:</b> <?php echo e($consulta->email); ?><br>

<b>Lugar:</b> <?php echo e($consulta->lugar); ?><br>

<b>Telefono:</b> <?php echo e($consulta->telefono); ?><br>
<b>Cantidad:</b> <?php echo e($consulta->cantidad); ?><br>
<b>Perfil de evento:</b> <?php echo e($consulta->perfil_evento); ?><br>
<b>Tipo de evento:</b> <?php echo e($consulta->tipo_evento); ?><br>
<b>Tipo de servicio:</b> <?php echo e($consulta->tipo_servicio); ?><br>

<b>Menu:</b> <?php echo e($consulta->menu); ?><br>

<b>Consulta:</b> <?php echo e($consulta->consulta); ?><br>

<?php /**PATH C:\xampp\htdocs\GitHub\galindez\resources\views/mails/mail.blade.php ENDPATH**/ ?>