<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="css/app.css">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    

<script src="js/app.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\GitHub\galindez\resources\views/welcome.blade.php ENDPATH**/ ?>